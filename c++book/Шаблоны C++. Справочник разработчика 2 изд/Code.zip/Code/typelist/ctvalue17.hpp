template<auto Value>
struct CTValue
{ 
  static constexpr auto value = Value;
};
